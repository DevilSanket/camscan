# Focused scanner product plan

## Customer requirement

Create an Android app that finds the four edges of a paper document, corrects perspective, and automatically turns its existing colors into a clean scan. Colored ink, stamps, logos, and highlights should remain recognizable. “Colorize” means improving an existing color photograph, as confirmed by the customer.

## Proposed experience

1. Take a photo or select an existing image.
2. Detect the document automatically and show its four corners.
3. Let the user adjust corners when the page is faint, partly hidden, or surrounded by distracting objects.
4. Apply perspective correction and automatic color cleanup immediately.
5. Compare the source and enhanced result, adjust enhancement strength if needed, and save or share the JPEG or PDF.

The default should need only capture and save for a clear, flat page. Keep the original available so enhancement is reversible.

## Implementation direction

Use an on-device pipeline with independent stages: image decoding and orientation, boundary detection, perspective correction, color enhancement, and export. An initial classical image-processing detector is practical for straight, high-contrast document edges. Score candidate quadrilaterals using area, shape plausibility, convexity, and edge support; reject weak candidates and expose a manual crop instead of silently cropping content.

For a clean color scan, estimate slow-changing illumination, reduce uneven shading, correct the paper's color cast conservatively, lift the background, increase readable contrast, and add restrained sharpness. Preserve saturation in colored marks and avoid applying pure black-and-white thresholding to the default output. These are proposed implementation choices, not findings about OKEN's code.

Keep capture, crop, and enhancement modules separate. This allows a learned document detector or improved shadow estimation to replace one stage later without changing the user flow. Process large photos on a worker thread with bounded input sizes, and release temporary image buffers promptly.

## Initial implementation

The Android implementation uses OpenCV on the device. Boundary detection combines Canny edges with a bright-paper mask, then scores convex four-sided contours. Images are reduced to a maximum edge of 960 pixels for detection, while perspective-corrected output is limited to 2600 pixels on its longest edge. A weak candidate returns no detection, allowing the user to confirm the crop manually.

Automatic color enhancement operates in Lab color space. It estimates illumination from a small image using morphological closing and a weighted blur of neutral-paper samples, adjusts luminance with bounded gains, and applies a small paper-color correction. Saturated artwork receives a smaller gain and bypasses the paper contrast stretch to avoid halos around large colored panels. The color channels remain available throughout the default filter. Optional original, grayscale, and black-and-white filters provide alternatives. This describes this project's `DocumentProcessor` source; it is not an assertion about OKEN's internals.

## Focus and limitations

The requested scope is scanning and enhancement. Accounts, cloud storage, OCR, signatures, subscriptions, and document conversion are unnecessary for this version. Use original app naming and UI assets.

A single-photo perspective transform handles flat pages; curved book pages require a separate dewarping method. Completely clipped highlights contain no recoverable detail. Severe shadows, low contrast against the background, glare, and partial page visibility need representative customer examples before quality can be guaranteed.

## Acceptance examples

| Input | Expected behavior |
| --- | --- |
| White form on a dark table | Four edges detected; square page; readable text |
| Angled receipt | Narrow page retained without clipping top or bottom |
| Colored certificate or stamp | Existing colors retained; background cleaned |
| Warm indoor lighting | Paper cast reduced without making colored marks gray |
| Page with broad soft shadow | More even background with legible text |
| Faint page edge or clutter | Manual corner adjustment available |
| Landscape or rotated photo | Orientation consistent through preview and export |

Verify saved dimensions, actual file existence, and JPEG/PDF readability as well as preview appearance. Test capture and image import on a physical Android phone before customer sign-off. Synthetic pictures help check geometry and regressions, but do not substitute for real customer scans.
