# Folio Scan for Android

A focused, native Android scanner: detect a paper document, correct its perspective, and automatically clean up its **existing colors**. Camera capture and photo import use the same offline OpenCV pipeline.

## Try it

Install the debug APK from `deliverables/` on an Android 8.0 or newer phone. `folio-scan-arm64-debug.apk` is the smaller build for modern ARM64 phones; `folio-scan-universal-debug.apk` includes ARM32, ARM64, x86, and x86_64. These are test builds signed with the development key.

1. Open **Folio Scan** and choose **Scan with camera** or **Import photo**. **Try a sample page** runs a generated photograph through the actual detector.
2. Check the detected corners. Drag them if needed; **Reset edges** selects the photograph bounds and **Rotate** turns the image clockwise.
3. Tap **Apply scan**. **Auto color** is selected automatically. Compare **Original**, **Gray**, and **B&W**.
4. **Save scan**, then export a JPG/PDF or share a PDF. Rename and delete are available on saved scans.

The camera can capture automatically after a detected page stays steady for about 1.6 seconds. Manual capture remains available. Permission denial leaves photo import available.

Scans are kept in private app storage. Export copies with the Android file picker before uninstalling the app. Processing does not use a server; the app requests no internet or broad storage permission. Exported copies are stored wherever the user chooses.

## Build

Open this folder in Android Studio, or use JDK 17, Android SDK platform 36, and the checked-in Gradle wrapper:

```sh
export JAVA_HOME=/path/to/jdk-17
./gradlew :app:assembleDebug
./gradlew :app:assembleDebug -PfolioAbi=arm64-v8a
```

On this workstation the JDK is `/home/sanket/.jdk/current` and SDK is `/home/sanket/Android/Sdk`. Set your own `sdk.dir` in `local.properties` or use `ANDROID_HOME`. Build output is `app/build/outputs/apk/debug/app-debug.apk`; each ABI build replaces that output, so copy it before building another variant.

```sh
./gradlew :app:lintDebug
./gradlew :app:connectedDebugAndroidTest
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

The connected tests require a device/emulator supported by the built APK. Native tests execute the real OpenCV JNI library, rather than a mocked algorithm.

## Main code

- `MainActivity.java`: capture/import, crop/preview flow, lifecycle restoration, library, export and sharing.
- `processing/DocumentProcessor.java`: contour scoring, four-point perspective warp, lighting normalization and color filters.
- `ui/CropImageView.java`: normalized, constrained, draggable document corners.
- `storage/ScanStore.java`: private JPEG library and single-page PDF export, bounded EXIF-aware photo decoding.
- `ui/ScanIllustration.java`: original vector illustration and synthetic sample photograph.

Detection is reduced to 960 px for speed; output is capped at 2600 px on the longest edge. A weak candidate produces an explicit manual crop. Auto color estimates page lighting and makes a conservative paper-color correction in Lab space while keeping color information. Its detector quality score is a geometric heuristic, not an accuracy probability.

## REA and OKEN

The supplied [REA project](https://github.com/morluto/rea) provides reverse-engineering tools, rather than scanner algorithms. REA was used to inspect this app’s built APK. The analysis, reproducible commands, target hash, and JSON evidence are in [docs/REA_FINDINGS.md](docs/REA_FINDINGS.md).

No OKEN APK was supplied. This app independently implements the requested detection and clean-color-scan behavior; it does not claim an exact reconstruction of OKEN. To compare and tune against OKEN, provide its APK and representative original photos with their resulting OKEN scans.

## Practical limits

The detector is intended for flat, rectangular pages. Faint boundaries, clutter, clipped pages, glare, and curved books may need manual correction. Enhancement cannot restore detail lost to blur or blown-out highlights, and broad colored artwork may become lighter. Customer photographs and a physical Android phone are needed before customer acceptance. This version exports one page per scan.

See [DESIGN.md](DESIGN.md) for the design decisions, [docs/PRODUCT_PLAN.md](docs/PRODUCT_PLAN.md) for the brainstorm, and [docs/VALIDATION.md](docs/VALIDATION.md) for recorded checks.

## Dependencies

OpenCV 4.12, AndroidX CameraX 1.4.2, Activity, Core, and EXIF Interface are resolved from Maven by Gradle. Their upstream licenses apply. [OpenCV](https://github.com/opencv/opencv/blob/4.12.0/LICENSE), [AndroidX](https://android.googlesource.com/platform/frameworks/support/+/androidx-main/LICENSE.txt).
