# REA investigation notes

Research date: 14 October 2026. This project implements the customer's requested document boundary detection and automatic cleanup of **existing colors**. It does not synthesize colors for monochrome photos.

## What is verified

REA is an investigation tool, rather than an Android scanning SDK. Its Android static-analysis commands require a local APK. The supplied GitHub link contains REA itself; it does not contain OKEN's implementation or an OKEN APK. No OKEN target APK was available for this investigation. Consequently, this project makes no claim to have recovered OKEN's algorithms or matched its outputs exactly. [REA repository](https://github.com/morluto/rea)

OKEN's own website describes automatic trimming, shadow removal, distortion correction, and image optimization. Its Play listing describes color correction and noise reduction. These establish the requested product behavior, but do not disclose the detector or enhancement pipeline. [OKEN website](https://www.okenscanner.com/), [Google Play listing](https://play.google.com/store/apps/details?id=com.cambyte.okenscan&hl=en)

## Environment and precise workflow

The current registry release inspected was `rea-agents@6.5.0`. The default Node executable reports `v22.14.0`, which is below REA's declared minimum. The bundled executable below reports `v24.19.0` and meets the requirement:

```text
/home/sanket/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node
```

A full Temurin JDK 17.0.20.1 was found at `/home/sanket/.jdk/current`; its `jdk.compiler` module is present. Android analysis additionally requires a full JDK 17 or newer, `ps` on Linux, and the upstream `jadx-headless-mcp-0.7.1-all.jar`. The pinned JAR digest is:

```text
6e5eacf500b64292bfb73c49797c1958f6ee44646e43e868039ae7feb573ff75
```

The command names come from the official Android analysis guide; `--format json` was verified against the installed 6.5.0 CLI help. `TARGET_APK` and discovered class/method names must be supplied; example placeholders are not evidence about OKEN.

```sh
export JAVA_HOME=/home/sanket/.jdk/current
export PATH=/home/sanket/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:"$JAVA_HOME/bin:$PATH"
export REA_JADX_MCP_JAR=/absolute/path/jadx-headless-mcp-0.7.1-all.jar
npx --yes rea-agents@6.5.0 inspect-android-package "$TARGET_APK" --format json
npx --yes rea-agents@6.5.0 search-android-classes "$TARGET_APK" "$QUERY" --format json
npx --yes rea-agents@6.5.0 inspect-android-class "$TARGET_APK" "$CLASS_NAME" --format json
npx --yes rea-agents@6.5.0 inspect-android-method "$TARGET_APK" "$CLASS_NAME" "$METHOD_NAME" --format json
npx --yes rea-agents@6.5.0 trace-android-references "$TARGET_APK" "$CLASS_NAME" --method-name "$METHOD_NAME" --format json
```

Use class inspection to identify overloads, then add `--overload-index N` where required. Retain APK SHA-256, engine identity, request, raw response, and limitations with each finding. Decompiled Java/smali and static references do not prove runtime behavior or an exact reconstruction. APK signature validation and native-library analysis are separate. [Static Android analysis guide](https://github.com/morluto/rea/blob/main/docs/android-analysis.md)

An installed app can be acquired from a connected emulator or phone using caller-supplied `adb`; REA does not create devices or install the SDK. The official acquisition flow is:

```sh
npx --yes rea-agents@6.5.0 list-adb-devices --format json
npx --yes rea-agents@6.5.0 resolve-adb-packages "$SERIAL" okenscan --format json
npx --yes rea-agents@6.5.0 inspect-adb-package "$SERIAL" com.cambyte.okenscan --format json
npx --yes rea-agents@6.5.0 pull-adb-package "$SERIAL" com.cambyte.okenscan --output-directory "$OUTPUT_DIRECTORY" --format json
```

Package pulling records the installed base and split APKs with hashes. The selected output directory must be new. Inspect the reported base APK; preserve the split set for resource/native follow-up. [ADB acquisition guide](https://github.com/morluto/rea/blob/main/docs/adb-device-analysis.md)

## Investigation status

The REA source and official documentation were inspected. REA 6.5.0 CLI help was successfully run without running `setup` or changing agent configuration. The official JADX JAR was downloaded to `/tmp/folio-rea-research/jadx-headless-mcp-0.7.1-all.jar` and its digest matched the pinned value above. With the selected Node 24 and JDK 17, `doctor --provider jadx --format json` returned scoped `healthy: true`; unrelated optional analysis providers and agent registrations were informational checks. Any analysis of this project's own APK is recorded separately as implementation verification, never as analysis of OKEN.

REA subsequently inspected Folio Scan's decoded manifest, processing-class inventory, and `detect`/`enhance` method bodies. The method source results were complete with no decompiler fallback. The [local evidence summary](rea/README.md) and its four raw JSON files document the observations and per-artifact hashes. This is static verification of this implementation; image quality and Android runtime behavior require separate tests.
