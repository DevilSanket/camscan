# Folio Scan

The customer needs two things: identify the page in a photograph and make its existing colors look like a clean scan. The app follows one short path: capture or import → confirm the page → automatically enhance → save or export.

## Design decisions

Use a quiet, bright workspace that lets the document carry the color. Palette: ink `#172B3A`, teal `#075E68`, paper `#F4F8FA`, white `#FFFFFF`, line `#DCE9ED`, soft teal `#E6F4F2`. Android sans-serif and sans-serif-medium keep small controls legible. Titles are 28–32sp; supporting text 14–16sp. Content and controls are left aligned except the capture guidance.

```
Library                  Page corners                Scan preview
Folio Scan               Back   Adjust page           Back   Your scan
Scan a page              Detected / adjust hint       Auto color applied
Document illustration    Full photograph + handles   Rectified page
Camera / Import          Reset / Rotate               Auto / Original / Gray / B&W
Recent saved scans       Apply scan                   Save scan
```

The memorable element is the paper itself, a specimen with colored ink that can be tried through the actual processing pipeline. Avoid a crowded dashboard: a single prominent camera action, a quieter import action, and saved documents below. Camera feedback describes observable state rather than displaying a made-up accuracy percentage.

## Scope and implementation

- Native Java Android app, API 26+, CameraX, OpenCV bundled for offline operation.
- Real contour-based quadrilateral detection; perspective correction; manual corner adjustment when detection is uncertain.
- Default Auto color: background-lighting correction and contrast enhancement while retaining colored ink.
- Original, grayscale, and black-and-white comparisons.
- Private local library, rename/delete, share, and user-selected JPG/PDF export.
- No account or server. Processing and saved files stay on the device.

This is an independent implementation of the requested behavior. Exact OKEN comparisons require a supplied APK and representative input/output pairs. REA is an investigation tool, not a document-processing library.

## Validation targets

Build an installable APK. Run fixture tests against Android's real OpenCV library for detection, negative inputs, cropping, and color retention; smoke-test sample/import/crop/filter/save/export flows on an emulator if available. A real device and diverse customer photographs are still needed to assess camera behavior and tune scan quality.
